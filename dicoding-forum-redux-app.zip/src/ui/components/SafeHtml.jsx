import { useMemo } from 'react'
import DOMPurify from 'dompurify'

/**
 * Render HTML string as sanitized markup.
 * Forum API returns content that may contain HTML tags like <br> / <div>.
 */
export default function SafeHtml ({ html, className = '', as = 'div' }) {
  const safe = useMemo(() => {
    return DOMPurify.sanitize(html || '', { USE_PROFILES: { html: true } })
  }, [html])

  const Tag = as
  return <Tag className={className} dangerouslySetInnerHTML={{ __html: safe }} />
}
