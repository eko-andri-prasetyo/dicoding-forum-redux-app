# Forum Diskusi (React + Redux)

Aplikasi forum diskusi untuk submission Dicoding **Menjadi React Web Developer Expert** — Proyek: **Membangun Aplikasi React dengan Redux**.

API Base URL: `https://forum-api.dicoding.dev/v1/`

## Fitur (sesuai kriteria)
- Register & Login
- List thread + info pembuat + total komentar
- Detail thread + komentar
- Buat thread (butuh login)
- Buat komentar (butuh login)
- Loading indicator ketika fetch API
- Redux Store untuk state yang bersumber dari API (threads, users, thread detail, leaderboards, auth)
- Tidak ada pemanggilan REST API langsung di komponen (API call ada di thunk)
- React StrictMode
- ESLint config (StandardJS) dan script lint

## Fitur opsional (nilai lebih)
- Votes thread & komentar (optimistic update)
- Halaman Leaderboards
- Filter thread berdasarkan kategori (client-side)

## Menjalankan (step-by-step)
1. **Install Node.js** (disarankan Node 18+).
2. Ekstrak ZIP project, lalu buka terminal di folder project.
3. Install dependencies:
   ```bash
   npm install
   ```
4. Jalankan mode development:
   ```bash
   npm run dev
   ```
   Buka URL yang muncul (biasanya http://localhost:5173).
5. Cek lint:
   ```bash
   npm run lint
   ```
6. Build production:
   ```bash
   npm run build
   npm run preview
   ```

## Catatan Teknis
- Token disimpan di `localStorage` dan dipakai sebagai header `Authorization: Bearer <token>`.
- Saat reload, aplikasi akan mencoba memuat profil dari endpoint `/users/me`.


## Catatan Dependensi ESLint
Project ini menggunakan ESLint v8 + eslint-config-standard v17 (kompatibel). Jika sebelumnya gagal install, hapus `node_modules` dan `package-lock.json`, lalu jalankan `npm install`.
